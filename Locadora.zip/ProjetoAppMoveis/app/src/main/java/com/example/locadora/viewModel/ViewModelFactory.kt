package com.example.locadora.viewModel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.locadora.model.database.dao.CarroDao
import com.example.locadora.viewModel.ui.theme.LocadoraTheme

class CarroViewModelFactory(
    private val carroDao: CarroDao
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CarroViewModel::class.java)) {
            return CarroViewModel(carroDao) as T
        }

        throw IllegalArgumentException("Classe ViewModel desconhecida")
    }
}