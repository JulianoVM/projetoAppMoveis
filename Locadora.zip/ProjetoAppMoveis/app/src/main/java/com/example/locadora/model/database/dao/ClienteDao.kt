package com.example.locadora.model.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.locadora.model.entity.Cliente

@Dao
interface ClienteDao {

    @Insert
    suspend fun inserir(cliente: Cliente)

    @Query("SELECT * FROM clientes")
    suspend fun buscarTodos(): List<Cliente>

}