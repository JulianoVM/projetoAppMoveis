package com.example.locadora.model

abstract class Validar {

    companion object {

        fun carroEmBranco(marca: String, modelo: String, ano: String, preco: String) : Boolean {
            return marca.isBlank() || modelo.isBlank() || ano.isBlank() || preco.isBlank()
        }

        fun espacosEmBranco(nome: String, email: String, senha: String) : Boolean {
            return nome.isBlank() || email.isBlank() || senha.isBlank()
        }

    }

}