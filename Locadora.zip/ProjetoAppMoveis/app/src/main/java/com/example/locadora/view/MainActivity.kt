package com.example.locadora.view


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.locadora.model.database.AppDatabase
import com.example.locadora.model.database.dao.ClienteDao
import com.example.locadora.model.entity.Cliente
import com.example.locadora.viewModel.AdminViewModel
import com.example.locadora.viewModel.AdminViewModelFactory
import com.example.locadora.viewModel.CarroViewModel
import com.example.locadora.viewModel.ClienteViewModel
import com.example.locadora.viewModel.ClienteViewModelFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val clienteViewModel: ClienteViewModel by viewModels {
        val dao = AppDatabase.getDatabase(applicationContext).getClienteDao()
        ClienteViewModelFactory(dao)
    }
    private val adminViewModel: AdminViewModel by viewModels {
        val dao = AppDatabase.getDatabase(applicationContext).getAdminDao()
        AdminViewModelFactory(dao)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppNavigation(adminViewModel,clienteViewModel)
        }
    }
    override fun onResume() {
        super.onResume()
        clienteViewModel.buscarTodos()
        adminViewModel.buscarTodos()

    }
}
@Composable
fun AppNavigation(adminViewModel: AdminViewModel,clienteViewModel: ClienteViewModel){
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "TelaMenu"){
        composable("TelaMenu") { TelaMenu(navController)  }
        composable("LoginCliente") {LoginCliente(navController,clienteViewModel) }
        composable("LoginAdmin") { LoginAdmin(navController,adminViewModel) }
        composable("CadastroCliente") {CadastroCliente(navController,clienteViewModel)  }
        composable("CadastrarAdmin") { CadastrarAdmin (navController,adminViewModel)  }
    }
}
@Composable
fun TelaMenu(navController: NavController) {

    Column(modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {

        Text(text = "BEM-VINDO À",fontSize = 22.sp)
        Text(text = "LOCADORA DE VEÍCULOS", fontSize = 22.sp)
        //espaço para separar texto
        Spacer(modifier = Modifier.height(20.dp))

        Text(text = "Logar como: ", fontSize = 18.sp)
        //espaço para separar texto do botão
        Spacer(modifier = Modifier.height(20.dp))

        Row (){
            Button(onClick ={navController.navigate("LoginCliente")
            })
            { Text("CLIENTE") }

            Spacer(modifier = Modifier.padding(20.dp))

            Button(onClick ={navController.navigate("LoginAdmin")
            })
            { Text("ADMIN") }
        }
    }
}
@Composable
fun LoginCliente(navController: NavController, clienteViewModel: ClienteViewModel){

    var email by remember { mutableStateOf("") }
    var senha by remember { mutableStateOf("") }
    val listaCliente by clienteViewModel.listaClientes
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {

        Text(text = "LOGIN CLIENTES", fontSize = 22.sp)
        //espaço para separar texto
        Spacer(modifier = Modifier.height(20.dp))

        TextField(value = email, onValueChange = {email = it}, label = { Text("Digite seu email: ")})
        Spacer(modifier = Modifier.height(5.dp))

        TextField(value = senha, onValueChange = {senha = it}, label = { Text("Digite sua senha: ")})
        Spacer(modifier = Modifier.height(5.dp))

        Row {
            Button(onClick = {
                //verificacao campos em branco
                if(email.isEmpty() or senha.isEmpty()){
                    Toast.makeText(context, "preencha todos os campos", Toast.LENGTH_LONG).show()
                }
                // Verifica se existe um cliente com o email e senha fornecidos
                val clienteEncontrado = listaCliente.find { it.email == email && it.senha == senha }
                if (clienteEncontrado != null) {
                    //redirecionamento para activity cliente
                    context.startActivity(Intent(context,ClienteActivity::class.java))
                } else {
                    //mensagem de senha ou email incorretos
                    Toast.makeText(context, "E-mail ou senha incorretos", Toast.LENGTH_LONG).show()
                }

            }) {
                Text("Fazer login")
            }
            Spacer(modifier = Modifier.padding(20.dp))
            Button(onClick = { navController.navigate("CadastroCliente") }) {
                Text("Fazer cadastro")
            }
        }
        Spacer(modifier = Modifier.padding(20.dp))
        Button(onClick = {
            navController.navigate("TelaMenu")
        }) {
            Text("Voltar para tela principal")
        }
    }


}
@Composable
fun CadastroCliente(navController: NavController,clienteViewModel: ClienteViewModel) {

    var nome by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var senha by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {

        Text(text = "CADASTRO DE CLIENTES", fontSize = 22.sp)
        //espaço para separar texto
        Spacer(modifier = Modifier.height(20.dp))

        TextField(
            value = nome,
            onValueChange = { nome = it },
            label = { Text("Digite seu nome: ") })
        Spacer(modifier = Modifier.height(5.dp))

        TextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Digite seu email: ") })
        Spacer(modifier = Modifier.height(5.dp))

        TextField(
            value = senha,
            onValueChange = { senha = it },
            label = { Text("Digite sua senha: ") })
        Spacer(modifier = Modifier.height(5.dp))

        Button(onClick = {
            val retorno: String? = clienteViewModel.inserirCliente(nome, email, senha)
            Toast.makeText(context, retorno, Toast.LENGTH_LONG).show()
            context.startActivity(Intent(context, ClienteActivity::class.java))

        }) {Text("Cadastrar!")}

        Spacer(modifier = Modifier.height(10.dp))

        Button(onClick ={navController.navigate("LoginCliente")
        })
        { Text("voltar para tela de login") }


    }
}
@Composable
fun LoginAdmin(navController: NavController,adminViewModel: AdminViewModel){
    var email by remember { mutableStateOf("") }
    var senha by remember { mutableStateOf("") }
    val listaAdmin by adminViewModel.listaAdmins
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {

        Text(text = "LOGIN ADMIN", fontSize = 22.sp)
        //espaço para separar texto
        Spacer(modifier = Modifier.height(20.dp))

        TextField(value = email, onValueChange = {email = it}, label = { Text("Digite seu email: ")})
        Spacer(modifier = Modifier.height(5.dp))

        TextField(value = senha, onValueChange = {senha = it}, label = { Text("Digite sua senha: ")})
        Spacer(modifier = Modifier.height(5.dp))

        Row {
            Button(onClick = {
                //verifica se nao esta com campos vazios
                if(email.isEmpty() or senha.isEmpty()){
                    Toast.makeText(context, "preencha todos os campos", Toast.LENGTH_LONG).show()
                }
                // Verifica se existe um cliente com o email e senha fornecidos
                val adminEncontrado = listaAdmin.find { it.email == email && it.senha == senha }
                if (adminEncontrado != null) {
                    context.startActivity(Intent(context, AdminActivity::class.java))
                } else {
                    Toast.makeText(context, "E-mail ou senha incorretos", Toast.LENGTH_LONG).show()
                }
            }) {
                Text("Fazer login")
            }
            Spacer(modifier = Modifier.padding(20.dp))
            Button(onClick = { navController.navigate("CadastrarAdmin") }) {
                Text("Fazer cadastro")
            }
        }
        Spacer(modifier = Modifier.padding(20.dp))

        Button(onClick = {
            navController.navigate("TelaMenu")
        }) {
            Text("Voltar para tela principal")
        }
    }

}
@Composable
fun CadastrarAdmin(navController: NavController,adminViewModel: AdminViewModel){
    var nome by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var senha by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {

        Text(text = "CADASTRO DE ADMINISTRADORES", fontSize = 22.sp)
        //espaço para separar texto
        Spacer(modifier = Modifier.height(20.dp))

        TextField(
            value = nome,
            onValueChange = { nome = it },
            label = { Text("Digite seu nome: ") })
        Spacer(modifier = Modifier.height(5.dp))

        TextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Digite seu email: ") })
        Spacer(modifier = Modifier.height(5.dp))

        TextField(
            value = senha,
            onValueChange = { senha = it },
            label = { Text("Digite sua senha: ") })
        Spacer(modifier = Modifier.height(5.dp))

        Button(onClick = {
            val retorno: String? = adminViewModel.inserirAdmin(nome, email, senha)
            Toast.makeText(context, retorno, Toast.LENGTH_LONG).show()
            context.startActivity(Intent(context, AdminActivity::class.java))

        }) {Text("Cadastrar!")}

        Spacer(modifier = Modifier.height(10.dp))

        Button(onClick ={navController.navigate("LoginAdmin")
        })
        { Text("voltar para tela de login") }


    }
}