package com.example.locadora.view

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.motionEventSpy
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.locadora.model.database.AppDatabase
import com.example.locadora.model.entity.Carro
import com.example.locadora.viewModel.AdminViewModel
import com.example.locadora.viewModel.AdminViewModelFactory
import com.example.locadora.viewModel.CarroViewModel
import com.example.locadora.viewModel.CarroViewModelFactory
import com.example.locadora.viewModel.ClienteViewModel
import com.example.locadora.viewModel.ClienteViewModelFactory

class AdminActivity : ComponentActivity() {

    private val carroViewModel: CarroViewModel by viewModels {
        val dao = AppDatabase.getDatabase(applicationContext).getCarroDao()
        CarroViewModelFactory(dao)
    }

    private val clienteViewModel : ClienteViewModel by viewModels{
        val dao = AppDatabase.getDatabase(applicationContext).getClienteDao()
        ClienteViewModelFactory(dao)
    }

    private val adminViewModel : AdminViewModel by viewModels {
        val dao = AppDatabase.getDatabase(applicationContext).getAdminDao()
        AdminViewModelFactory(dao)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppNavigation(carroViewModel, adminViewModel,clienteViewModel)
        }
    }

    override fun onResume() {
        super.onResume()
        carroViewModel.carregarCarros()
        clienteViewModel.buscarTodos()
        adminViewModel.buscarTodos()
    }
}


@Composable
fun AppNavigation(
    carroViewModel: CarroViewModel,
    adminViewModel: AdminViewModel,
    clienteViewModel: ClienteViewModel
) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "TelaAdmin") {
        composable("TelaAdmin") { TelaAdmin(navController,carroViewModel,clienteViewModel,adminViewModel) }
        composable("CadastrarVeiculo") { CadastroVeiculo(navController,carroViewModel) }
    }
}

@Composable
fun TelaAdmin(
    navController: NavController,
    carroViewModel: CarroViewModel,
    clienteViewModel: ClienteViewModel,
    adminViewModel: AdminViewModel
) {
    val carros by carroViewModel.listaCarros
//    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize()) {
        Spacer(Modifier.padding(10.dp))
        Text("carroasdfghjkl;")
        Spacer(Modifier.padding(10.dp))

        LazyColumn {
            items(carros) { carro ->
                Text(
                    text = "${carro.id} ${carro.marca} ${carro.modelo} ${carro.ano} ${carro.preco}",
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 18.sp
                )

                Spacer(modifier = Modifier.height(5.dp))

            }
        }

        Spacer(Modifier.padding(10.dp))
        Text("carrodfghjk")
        Spacer(Modifier.padding(10.dp))

        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = { navController.navigate("CadastrarVeiculo") },
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text("Cadastrar Novo Veículo")
        }
    }
}

@Composable
fun CadastroVeiculo(navController: NavController,carroViewModel: CarroViewModel){
    var marca by remember { mutableStateOf("") }
    var modelo by remember { mutableStateOf("") }
    var ano by remember { mutableStateOf("") }
    var preco by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column (modifier = Modifier.fillMaxSize().padding(50.dp),
        horizontalAlignment = Alignment.CenterHorizontally){
        Text("CADASTRO DE VEICULO:")
        Spacer(Modifier.padding(3.dp))
        Text(text ="========================================")
        Spacer(Modifier.padding(15.dp))

        TextField(
            value = marca,
            onValueChange = { marca = it },
            label = { Text("Digite a marca do novo veiculo: ") })
        Spacer(modifier = Modifier.height(5.dp))
        TextField(
            value = modelo,
            onValueChange = { modelo = it },
            label = { Text("Digite a modelo do novo veiculo: ") })
        Spacer(modifier = Modifier.height(5.dp))
        TextField(
            value = ano,
            onValueChange = { ano = it },
            label = { Text("Digite o ano do novo veiculo: ") })
        Spacer(modifier = Modifier.height(5.dp))
        TextField(
            value = preco,
            onValueChange = { preco = it },
            label = { Text("Digite o preço do novo veiculo: ") })
        Spacer(modifier = Modifier.height(5.dp))

        Button(onClick = {
//            val retorno: String? = carroViewModel.salvarCarro(marca,modelo,ano,preco).toString()
//            Toast.makeText(context, retorno, Toast.LENGTH_LONG).show()
            carroViewModel.salvarCarro(marca,modelo,ano,preco)
//            Toast.makeText(context,"botao clicado",Toast.LENGTH_SHORT).show()
        }) {Text("Cadastrar!")}

        Button(onClick = {navController.popBackStack()}) {
            Text("voltar para veiculos")
        }
    }
}
@Composable
fun ExcluirVeiculo(){

}
@Composable
fun EditarVeiculo(){

}
@Composable
fun CarroItem(carro: Carro) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = "Marca: ${carro.marca}", fontSize = 18.sp)
            Text(text = "Modelo: ${carro.modelo}", fontSize = 16.sp)
            Text(text = "Ano: ${carro.ano}", fontSize = 16.sp)
            Text(text = "Preço: R$ ${carro.preco}", fontSize = 16.sp)
        }
    }
}  
