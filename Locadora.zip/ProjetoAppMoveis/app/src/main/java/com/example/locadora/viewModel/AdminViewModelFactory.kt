package com.example.locadora.viewModel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.locadora.model.database.dao.AdminDao

class AdminViewModelFactory(
    private val adminDao: AdminDao
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AdminViewModel::class.java)) {
            return AdminViewModel(adminDao) as T
        }

        throw IllegalArgumentException("Classe ViewModel desconhecida")
    }
}