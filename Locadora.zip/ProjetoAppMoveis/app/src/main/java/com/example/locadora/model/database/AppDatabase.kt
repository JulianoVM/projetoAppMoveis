package com.example.locadora.model.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.locadora.model.database.dao.AdminDao
import com.example.locadora.model.database.dao.CarroDao
import com.example.locadora.model.database.dao.ClienteDao
import com.example.locadora.model.entity.Admin
import com.example.locadora.model.entity.Carro
import com.example.locadora.model.entity.Cliente

@Database(entities = [Admin::class, Carro::class, Cliente::class], version = 2)
abstract class AppDatabase : RoomDatabase() {

    abstract fun getAdminDao(): AdminDao
    abstract fun getCarroDao(): CarroDao
    abstract fun getClienteDao(): ClienteDao

    companion object {

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {

            return INSTANCE ?: synchronized(this) {

                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_database"
                ).addMigrations(MIGRATION_1_2).build()

                INSTANCE = instance

                return instance

            }
        }

        private val MIGRATION_1_2 = object : Migration(1,2) {

            override fun migrate(database: SupportSQLiteDatabase) {

                database.execSQL("CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nome TEXT NOT NULL, email TEXT NOT NULL, senha TEXT NOT NULL)")
                database.execSQL("CREATE TABLE IF NOT EXISTS clientes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nome TEXT NOT NULL, email TEXT NOT NULL, senha TEXT NOT NULL)")
                database.execSQL("ALTER TABLE carros ADD COLUMN clienteId INTEGER NOT NULL DEFAULT 0 REFERENCES clientes(id) ON DELETE CASCADE")

            }
        }

    }
}