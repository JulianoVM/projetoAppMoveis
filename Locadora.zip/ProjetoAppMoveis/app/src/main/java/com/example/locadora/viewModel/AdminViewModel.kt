package com.example.locadora.viewModel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.locadora.model.Validar
import com.example.locadora.model.database.dao.AdminDao
import com.example.locadora.model.entity.Admin
import kotlinx.coroutines.launch

class AdminViewModel(private val adminDao: AdminDao) : ViewModel() {
    var listaAdmins = mutableStateOf(listOf<Admin>())
    var listaEmails = mutableStateOf(listOf<String>())

    init {
        buscarTodos()
        buscarEmails()
    }

    fun inserirAdmin(nome: String, email: String, senha: String) : String {
        if (Validar.espacosEmBranco(nome, email, senha)) {
            return "Preencha todos os dados do admin"
        }

        if (listaEmails.value.contains(email)) {
            return "Usuário já cadastrado"
        }

        viewModelScope.launch {
            val admin = Admin(nome = nome, email = email, senha = senha)
            adminDao.inserir(admin)
            buscarTodos()
            buscarEmails()
        }

        return "Admin cadastrado com sucesso!"
    }

    fun buscarTodos() {
        viewModelScope.launch {
            listaAdmins.value = adminDao.buscarTodos()
        }
    }

    fun buscarEmails() {
        viewModelScope.launch {
            listaEmails.value = adminDao.buscarEmails()
        }
    }
}