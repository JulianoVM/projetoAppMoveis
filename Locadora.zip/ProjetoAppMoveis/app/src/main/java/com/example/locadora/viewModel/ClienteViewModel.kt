package com.example.locadora.viewModel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.locadora.model.Validar
import com.example.locadora.model.database.dao.ClienteDao
import com.example.locadora.model.entity.Cliente
import kotlinx.coroutines.launch

class ClienteViewModel(private val clienteDao: ClienteDao) : ViewModel() {
//    var clienteAtivoId: Int = 0 // Armazena o ID do cliente logado
    var listaClientes = mutableStateOf(listOf<Cliente>())
    var listaEmails = mutableStateOf(listOf<String>())

    init {
        buscarTodos()
    }

    fun inserirCliente(nome: String, email: String, senha: String) : String {
        if (Validar.espacosEmBranco(nome, email, senha)) {
            return "Preencha todos os dados do cliente"
        }

        if (listaEmails.value.contains(email)) {
            return "Usuário já cadastrado"
        }

        viewModelScope.launch {
            val cliente = Cliente(nome = nome, email = email, senha = senha)
            clienteDao.inserir(cliente)
            buscarTodos()
        }

        return "Cliente cadastrado com sucesso!"
    }


//    fun autenticarCliente(clienteId: Int) {
//        clienteAtivoId = clienteId
//    }

    fun buscarTodos() {
        viewModelScope.launch {
            listaClientes.value = clienteDao.buscarTodos()
        }
    }
}