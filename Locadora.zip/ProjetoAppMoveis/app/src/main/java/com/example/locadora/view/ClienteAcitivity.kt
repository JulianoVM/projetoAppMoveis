package com.example.locadora.view

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.locadora.model.database.AppDatabase
import com.example.locadora.viewModel.CarroViewModel
import com.example.locadora.viewModel.CarroViewModelFactory
import com.example.locadora.viewModel.ClienteViewModel
import com.example.locadora.viewModel.ClienteViewModelFactory

class ClienteActivity : ComponentActivity() {
    private val carroViewModel: CarroViewModel by viewModels {
        val dao = AppDatabase.getDatabase(applicationContext).getCarroDao()
        CarroViewModelFactory(dao)
    }
    private val clienteViewModel: ClienteViewModel by viewModels {
        val dao = AppDatabase.getDatabase(applicationContext).getClienteDao()
        ClienteViewModelFactory(dao)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppNavigation(clienteViewModel,carroViewModel)
        }
    }

    override fun onResume() {
        super.onResume()
        clienteViewModel.buscarTodos()
        carroViewModel.carregarCarros()

    }
}

@Composable
fun AppNavigation(clienteViewModel: ClienteViewModel,carroViewModel: CarroViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "TelaCliente") {
        composable("TelaCliente") { TelaCliente(navController,carroViewModel,clienteViewModel) }
        composable("carrosCliente") { CarrosCliente(navController) }
    }
}

@Composable
fun TelaCliente(navController: NavController, carroViewModel: CarroViewModel,clienteViewModel: ClienteViewModel) {
    val carros = carroViewModel.listaCarros.value
    // Variável de estado para exibir ou ocultar a caixa de diálogo
    var mostrarCaixaDialogo by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }

    if (carros.isEmpty()) {
        // Exibe um Toast se não houver carros
        Toast.makeText(navController.context, "Nenhum carro disponível", Toast.LENGTH_SHORT).show()
    }

//==================================================================================================

//    if (mostrarCaixaDialogo) {
//        InserirCarro(onConfirm = {
//            editarCarro?.let { carroViewModel.editarCarro(ano = ano.carroSelecionado, modelo = modelo.carroSelecionado,
//                marca = marca.carroSelecionado, preco = preco.carroSelecionado, clienteId = ) }
//            mostrarCaixaDialogo = false
//        }, onDismiss = { mostrarCaixaDialogo = false })
//    }

//==================================================================================================

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Text(text = "Seja bem-vindo", fontSize = 18.sp)
        Spacer(Modifier.padding(5.dp))

        Button(onClick = {
            navController.navigate("carrosCliente")
        }) {
            Text("Meus carros")
        }
        Spacer(Modifier.padding(15.dp))

        Text(text = "=============================================")
        Spacer(Modifier.padding(10.dp))

        // LazyColumn to display cars
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(carros) { carro ->
                // Each car block
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Car details
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Modelo: ${carro.modelo}", fontSize = 16.sp)
                        Text(text = "Marca: ${carro.marca}", fontSize = 16.sp)
                        Text(text = "Ano: ${carro.ano}", fontSize = 16.sp)
                        Text(text = "Preço: R$ ${carro.preco}", fontSize = 16.sp)
                    }

//                    // Button for action
//                    Button(onClick = InserirCarro(),
//                        modifier = Modifier.padding(start = 10.dp)
//                    ) {
//                        Text(text = "Alugar")
//                    }
                }
            }
        }
    }
}






//
//@Composable
//fun InserirCarro(onConfirm: () -> Unit, onDismiss: () -> Unit) {
//    AlertDialog(
//        onDismissRequest = onDismiss,
//        title = { Text(text = "Confirmar operação") },
//        text = { Text(text = "Tem certeza que deseja alugar este carro?") },
//        confirmButton = {
//            Button(onClick = onConfirm) {
//                Text(text = "Sim, alugar")
//            }
//        },
//        dismissButton = {
//            Button(onClick = onDismiss) {
//                Text(text = "Não, cancelar")
//            }
//        }
//    )
//}











@Composable
fun CarrosCliente(navController: NavController) {

    Column {
        Button(modifier = Modifier.padding(10.dp), onClick = {navController.navigate("TelaCliente")
        })
        {
            Text(text = " X ")
            Spacer(Modifier.padding(3.dp))

        }
    }
    Column (modifier = Modifier.fillMaxSize().padding(50.dp),
        horizontalAlignment = Alignment.CenterHorizontally){
        Text("MEUS CARROS:")
        Spacer(Modifier.padding(3.dp))
        Text(text ="========================================")
        Spacer(Modifier.padding(5.dp))
    }
}