package com.example.locadora.model.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.locadora.model.entity.Carro

@Dao
interface CarroDao {

    @Insert
    suspend fun inserir(carro: Carro)

    @Query("SELECT * FROM carros")
    suspend fun buscarTodos(): List<Carro>


    @Delete
    suspend fun deletar(carro: Carro)

    @Update
    suspend fun atualizar(carro: Carro)
}