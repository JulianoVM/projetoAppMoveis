package com.example.locadora.viewModel


import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.locadora.model.Validar
import com.example.locadora.model.database.dao.CarroDao
import com.example.locadora.model.entity.Carro
import kotlinx.coroutines.launch

class CarroViewModel(private val carroDao: CarroDao) : ViewModel() {

    var listaCarros = mutableStateOf(listOf<Carro>())

    init {
        carregarCarros()
    }

    fun salvarCarro(marca: String, modelo: String, ano: String, preco: String): String {

//        if (Validar.carroEmBranco(marca, modelo, ano, preco)) {
//            return "Preencha todos os campos do carro!"
//        }
        val carro = Carro( marca = marca, modelo = modelo, ano = ano, preco = preco)

        viewModelScope.launch {
            carroDao.inserir(carro)
            carregarCarros()

        }

        return "Carro salvo com sucesso!"
    }

    fun carregarCarros() {
        viewModelScope.launch {
            listaCarros.value = carroDao.buscarTodos()
        }
    }



























    fun excluirCarro(carro: Carro) {
        viewModelScope.launch {
            carroDao.deletar(carro)
            carregarCarros()
        }
    }










    fun editarCarro(id: Int, marca: String, modelo: String, ano: String, preco: String, clienteId: Int, ): String {
        if (Validar.carroEmBranco(marca, modelo, ano, preco)) {
            return "Preencha todos os campos do carro!"
        }

        val carro = listaCarros.value.find { it.id == id } ?: return "Erro ao atualizar carro"
        val carroAtualizado = carro.copy(marca = marca, modelo = modelo, ano = ano, preco = preco)

        viewModelScope.launch {
            carroDao.atualizar(carroAtualizado)
            carregarCarros()
        }

        return "Operação realizada com sucesso!"
    }
















    fun vincularCarroAoCliente(carro: Carro, clienteId: Int) {
        viewModelScope.launch {
            val carroAtualizado = carro.copy()
            carroDao.atualizar(carroAtualizado)
            carregarCarros()
        }
    }

}