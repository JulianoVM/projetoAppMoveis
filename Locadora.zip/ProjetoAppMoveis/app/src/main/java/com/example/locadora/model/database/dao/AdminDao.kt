package com.example.locadora.model.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.locadora.model.entity.Admin

@Dao
interface AdminDao {

    @Insert
    suspend fun inserir(admin: Admin)

    @Query("SELECT * FROM admins")
    suspend fun buscarTodos(): List<Admin>

    @Query("SELECT email FROM admins")
    suspend fun buscarEmails(): List<String>

}